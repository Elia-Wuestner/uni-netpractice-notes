# Uni Network Practice Notes

Notes for the Praktikum Rechnernetze (networking practice) course at HdM Stuttgart.

[![hydrun CI](https://github.com/pojntfx/uni-netpractice-notes/actions/workflows/hydrun.yaml/badge.svg)](https://github.com/pojntfx/uni-netpractice-notes/actions/workflows/hydrun.yaml)

## Overview

You can [view the notes on GitHub pages](https://pojntfx.github.io/uni-netpractice-notes/) or [download them from GitHub releases](https://github.com/pojntfx/uni-netpractice-notes/releases/latest).

## License

Uni Network Practice Notes (c) 2021 Felix Pojtinger and contributors

SPDX-License-Identifier: AGPL-3.0
